<?php

declare(strict_types=1);

require __DIR__.'/../../vendor/autoload.php';
$app = require __DIR__.'/../../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

echo 'DB='.config('database.connections.mysql.database').PHP_EOL;
echo 'hasTable='.(Illuminate\Support\Facades\Schema::hasTable('external_identities') ? 'yes' : 'no').PHP_EOL;

$row = Illuminate\Support\Facades\DB::table('migrations')
    ->where('migration', 'like', '%external_identities%')
    ->first();

echo 'migration_row='.json_encode($row).PHP_EOL;
