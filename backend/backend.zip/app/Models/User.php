<?php

declare(strict_types=1);

namespace App\Models;

use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasApiTokens, HasFactory, HasRoles, Notifiable, SoftDeletes;

    /**
     * Spatie Permission must resolve against the `web` guard even when the
     * request is authenticated via Sanctum (`auth:sanctum` switches the
     * default auth driver to `sanctum`). Roles/permissions are seeded for `web`.
     */
    protected string $guard_name = 'web';

    /**
     * @var list<string>
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'email',
        'password',
        'vendor_id',
        'phone',
        'teams',
        'whatsapp',
        'extension',
        'job_title_id',
        'is_active',
    ];

    /**
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'is_active' => 'boolean',
            'vendor_id' => 'integer',
            'job_title_id' => 'integer',
        ];
    }

    /**
     * @return Attribute<string, never>
     */
    protected function fullName(): Attribute
    {
        return Attribute::make(
            get: fn (): string => trim("{$this->first_name} {$this->last_name}"),
        )->shouldCache();
    }

    /**
     * Microsoft Teams handle on `users.teams`.
     *
     * Spatie Permission 8.3 defines HasRoles::teams() as a dummy BelongsToMany
     * even when `permission.teams` is false. That relation selects
     * `model_has_roles.team_id`, which this schema does not have. Overriding it
     * with an attribute keeps the column readable after create (when it is not
     * yet present on the in-memory model) without querying Spatie's pivot.
     *
     * @return Attribute<string|null, string|null>
     */
    protected function teams(): Attribute
    {
        return Attribute::make(
            get: static fn (mixed $value): ?string => $value === null ? null : (string) $value,
            set: static fn (mixed $value): ?string => $value === null || $value === '' ? null : (string) $value,
        );
    }

    /**
     * @return BelongsTo<Vendor, $this>
     */
    public function vendor(): BelongsTo
    {
        return $this->belongsTo(Vendor::class);
    }

    /**
     * @return BelongsTo<JobTitle, $this>
     */
    public function jobTitle(): BelongsTo
    {
        return $this->belongsTo(JobTitle::class);
    }

    /**
     * @return HasMany<ApplicationAssignment, $this>
     */
    public function assignments(): HasMany
    {
        return $this->hasMany(ApplicationAssignment::class);
    }

    /**
     * @return HasMany<UserOperationalArea, $this>
     */
    public function operationalAreas(): HasMany
    {
        return $this->hasMany(UserOperationalArea::class);
    }

    /**
     * @return list<string>
     */
    public function areaCodes(): array
    {
        return $this->operationalAreas
            ->map(static fn (UserOperationalArea $row): string => $row->area instanceof \BackedEnum
                ? $row->area->value
                : (string) $row->area)
            ->values()
            ->all();
    }

    /**
     * @return HasOne<UserDashboardLayout, $this>
     */
    public function dashboardLayout(): HasOne
    {
        return $this->hasOne(UserDashboardLayout::class);
    }

    public function isSuperAdmin(): bool
    {
        return $this->hasRole('super_admin');
    }

    /**
     * Whether the user has an active (non-ended) assignment on the application.
     */
    public function hasOpenAssignmentTo(Application|int $application): bool
    {
        $applicationId = $application instanceof Application
            ? (int) $application->getKey()
            : $application;

        return in_array($applicationId, $this->openAssignedApplicationIds(), true);
    }

    /**
     * @return list<int>
     */
    public function openAssignedApplicationIds(): array
    {
        if ($this->openAssignedApplicationIdsCache !== null) {
            return $this->openAssignedApplicationIdsCache;
        }

        /** @var list<int> $ids */
        $ids = $this->assignments()
            ->open()
            ->pluck('application_id')
            ->map(static fn (mixed $id): int => (int) $id)
            ->values()
            ->all();

        return $this->openAssignedApplicationIdsCache = $ids;
    }

    /**
     * @var list<int>|null
     */
    private ?array $openAssignedApplicationIdsCache = null;
}
