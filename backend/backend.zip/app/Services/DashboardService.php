<?php

declare(strict_types=1);

namespace App\Services;

use App\Enums\HaModel;
use App\Models\Application;
use App\Models\ApplicationAssignment;
use App\Models\Department;
use App\Models\InfraLicense;
use App\Models\License;
use App\Models\NetworkOpsLicense;
use App\Models\ServiceDeskLicense;
use App\Models\SmartFacilitiesLicense;
use App\Models\Technology;
use App\Models\User;
use App\Models\Vendor;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Spatie\Activitylog\Models\Activity;

class DashboardService
{
    private const int CACHE_TTL_SECONDS = 60;

    /**
     * @return array{
     *     totals: array{
     *         applications: int,
     *         active_users: int,
     *         vendors: int,
     *         technologies: int,
     *         licenses: int,
     *         assignments: int,
     *         open_assignments: int
     *     },
     *     charts: array{
     *         applications_by_status: list<array{name_en: string, name_ar: string, count: int}>,
     *         assignments_by_app_role: list<array{name: string, name_en: string, name_ar: string, count: int}>,
     *         technologies_usage: list<array{name: string, name_en: string, name_ar: string, count: int}>,
     *         employees_per_application: list<array{name_en: string, name_ar: string, count: int}>,
     *         applications_by_department: list<array{name_en: string, name_ar: string, count: int}>,
     *         applications_by_ha_model: list<array{key: string, name_en: string, name_ar: string, count: int}>,
     *         license_usage: list<array{key: string, name_en: string, name_ar: string, count: int}>,
     *         infra_license_usage: list<array{key: string, name_en: string, name_ar: string, count: int}>,
     *         service_desk_license_usage: list<array{key: string, name_en: string, name_ar: string, count: int}>,
     *         network_ops_license_usage: list<array{key: string, name_en: string, name_ar: string, count: int}>,
     *         smart_facilities_license_usage: list<array{key: string, name_en: string, name_ar: string, count: int}>,
     *         license_status_distribution: list<array{key: string, name_en: string, name_ar: string, count: int}>,
     *         licenses_by_environment: list<array{key: string, name_en: string, name_ar: string, count: int}>
     *     },
     *     recent_activity: list<array<string, mixed>>
     * }
     */
    public function index(?User $actor = null): array
    {
        $summary = Cache::remember('dashboard.summary', self::CACHE_TTL_SECONDS, function (): array {
            return $this->buildSummary();
        });

        return $this->filterForActor($summary, $actor);
    }

    /**
     * @param  array<string, mixed>  $summary
     * @return array<string, mixed>
     */
    private function filterForActor(array $summary, ?User $actor): array
    {
        $canApplications = $actor instanceof User && $actor->can('applications.view');
        $canUsers = $actor instanceof User && $actor->can('users.view');
        $canVendors = $actor instanceof User && $actor->can('vendors.view');
        $canTechnologies = $actor instanceof User && $actor->can('technologies.view');
        $canLicenses = $actor instanceof User && $actor->can('licenses.view');
        $canInfraLicenses = $actor instanceof User && $actor->can('infra-licenses.view');
        $canServiceDeskLicenses = $actor instanceof User && $actor->can('service-desk-licenses.view');
        $canNetworkOpsLicenses = $actor instanceof User && $actor->can('network-ops-licenses.view');
        $canSmartFacilitiesLicenses = $actor instanceof User && $actor->can('smart-facilities-licenses.view');
        $canAssignments = $actor instanceof User && $actor->can('assignments.view');
        $canActivity = $actor instanceof User && $actor->can('activity-log.view');

        /** @var array<string, int> $totals */
        $totals = $summary['totals'];
        /** @var array<string, mixed> $charts */
        $charts = $summary['charts'];

        return [
            'totals' => [
                'applications' => $canApplications ? $totals['applications'] : 0,
                'active_users' => $canUsers ? $totals['active_users'] : 0,
                'vendors' => $canVendors ? $totals['vendors'] : 0,
                'technologies' => $canTechnologies ? $totals['technologies'] : 0,
                'licenses' => $canLicenses ? $totals['licenses'] : 0,
                'assignments' => $canAssignments ? $totals['assignments'] : 0,
                'open_assignments' => $canAssignments ? $totals['open_assignments'] : 0,
            ],
            'charts' => [
                'applications_by_status' => $canApplications ? $charts['applications_by_status'] : [],
                'assignments_by_app_role' => $canAssignments ? $charts['assignments_by_app_role'] : [],
                'technologies_usage' => $canTechnologies ? $charts['technologies_usage'] : [],
                'employees_per_application' => $canAssignments ? $charts['employees_per_application'] : [],
                'applications_by_department' => $canApplications ? $charts['applications_by_department'] : [],
                'applications_by_ha_model' => $canApplications ? $charts['applications_by_ha_model'] : [],
                'license_usage' => $canLicenses ? $charts['license_usage'] : [],
                'infra_license_usage' => $canInfraLicenses ? $charts['infra_license_usage'] : [],
                'service_desk_license_usage' => $canServiceDeskLicenses ? $charts['service_desk_license_usage'] : [],
                'network_ops_license_usage' => $canNetworkOpsLicenses ? $charts['network_ops_license_usage'] : [],
                'smart_facilities_license_usage' => $canSmartFacilitiesLicenses ? $charts['smart_facilities_license_usage'] : [],
                'license_status_distribution' => $canLicenses ? $charts['license_status_distribution'] : [],
                'licenses_by_environment' => $canLicenses ? $charts['licenses_by_environment'] : [],
            ],
            'recent_activity' => $canActivity ? $summary['recent_activity'] : [],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function buildSummary(): array
    {
        $applicationsByStatus = Application::query()
            ->select(
                'application_statuses.name_en',
                'application_statuses.name_ar',
                DB::raw('COUNT(*) as count'),
            )
            ->join('application_statuses', 'applications.status_id', '=', 'application_statuses.id')
            ->groupBy('application_statuses.id', 'application_statuses.name_en', 'application_statuses.name_ar')
            ->orderBy('application_statuses.name_en')
            ->get()
            ->map(static fn ($row): array => [
                'name_en' => (string) $row->name_en,
                'name_ar' => (string) $row->name_ar,
                'count' => (int) $row->count,
            ])
            ->values()
            ->all();

        $assignmentsByRole = ApplicationAssignment::query()
            ->select('app_roles.name', DB::raw('COUNT(*) as count'))
            ->join('app_roles', 'application_assignments.app_role_id', '=', 'app_roles.id')
            ->whereNull('application_assignments.ended_at')
            ->groupBy('app_roles.name')
            ->orderBy('app_roles.name')
            ->get()
            ->map(static fn ($row): array => [
                'name' => (string) $row->name,
                'name_en' => (string) $row->name,
                'name_ar' => (string) $row->name,
                'count' => (int) $row->count,
            ])
            ->values()
            ->all();

        $technologiesUsage = DB::table('application_technology')
            ->join('technologies', 'application_technology.technology_id', '=', 'technologies.id')
            ->join('applications', 'application_technology.application_id', '=', 'applications.id')
            ->whereNull('technologies.deleted_at')
            ->whereNull('applications.deleted_at')
            ->where('technologies.is_active', true)
            ->groupBy('technologies.id', 'technologies.name')
            ->orderByDesc(DB::raw('COUNT(DISTINCT application_technology.application_id)'))
            ->orderBy('technologies.name')
            ->limit(10)
            ->get([
                'technologies.name',
                DB::raw('COUNT(DISTINCT application_technology.application_id) as count'),
            ])
            ->map(static fn ($row): array => [
                'name' => (string) $row->name,
                'name_en' => (string) $row->name,
                'name_ar' => (string) $row->name,
                'count' => (int) $row->count,
            ])
            ->values()
            ->all();

        $employeesPerApplication = ApplicationAssignment::query()
            ->select(
                'applications.id',
                'applications.name_en',
                'applications.name_ar',
                DB::raw('COUNT(DISTINCT application_assignments.user_id) as count'),
            )
            ->join('applications', 'application_assignments.application_id', '=', 'applications.id')
            ->whereNull('application_assignments.ended_at')
            ->whereNull('applications.deleted_at')
            ->groupBy('applications.id', 'applications.name_en', 'applications.name_ar')
            ->orderByDesc('count')
            ->orderBy('applications.name_en')
            ->limit(10)
            ->get()
            ->map(static fn ($row): array => [
                'id' => (int) $row->id,
                'name_en' => (string) $row->name_en,
                'name_ar' => (string) $row->name_ar,
                'count' => (int) $row->count,
            ])
            ->values()
            ->all();

        $applicationsByDepartment = Department::query()
            ->select(
                'departments.name_en',
                'departments.name_ar',
                DB::raw('COUNT(applications.id) as count'),
            )
            ->leftJoin('applications', static function ($join): void {
                $join->on('applications.department_id', '=', 'departments.id')
                    ->whereNull('applications.deleted_at');
            })
            ->groupBy('departments.id', 'departments.name_en', 'departments.name_ar')
            ->orderByDesc('count')
            ->orderBy('departments.name_en')
            ->limit(12)
            ->get()
            ->map(static fn ($row): array => [
                'name_en' => (string) $row->name_en,
                'name_ar' => (string) $row->name_ar,
                'count' => (int) $row->count,
            ])
            ->values()
            ->all();

        $haModelCounts = Application::query()
            ->select('ha_model', DB::raw('COUNT(*) as count'))
            ->whereNotNull('ha_model')
            ->groupBy('ha_model')
            ->get()
            ->mapWithKeys(static function ($row): array {
                $key = $row->ha_model instanceof HaModel
                    ? $row->ha_model->value
                    : (string) $row->ha_model;

                return [$key => (int) $row->count];
            })
            ->all();

        $haModelLabels = [
            HaModel::ActiveActive->value => ['name_en' => 'Active/Active', 'name_ar' => 'نشط/نشط'],
            HaModel::ActivePassive->value => ['name_en' => 'Active/Passive', 'name_ar' => 'نشط/خامل'],
            HaModel::HotStandby->value => ['name_en' => 'Hot Standby', 'name_ar' => 'استعداد ساخن'],
            HaModel::ColdStandby->value => ['name_en' => 'Cold Standby', 'name_ar' => 'استعداد بارد'],
        ];

        $applicationsByHaModel = [];
        foreach ($haModelLabels as $key => $labels) {
            $applicationsByHaModel[] = [
                'key' => $key,
                'name_en' => $labels['name_en'],
                'name_ar' => $labels['name_ar'],
                'count' => (int) ($haModelCounts[$key] ?? 0),
            ];
        }

        $licenseUsage = $this->licenseUsageChart(License::class);
        $infraLicenseUsage = $this->licenseUsageChart(InfraLicense::class);
        $serviceDeskLicenseUsage = $this->licenseUsageChart(ServiceDeskLicense::class);
        $networkOpsLicenseUsage = $this->licenseUsageChart(NetworkOpsLicense::class);
        $smartFacilitiesLicenseUsage = $this->licenseUsageChart(SmartFacilitiesLicense::class);

        $today = now()->toDateString();
        $within30 = now()->addDays(30)->toDateString();

        $licenseStatusCounts = License::query()
            ->selectRaw(
                'SUM(CASE WHEN end_date IS NOT NULL AND end_date < ? THEN 1 ELSE 0 END) as expired_count',
                [$today],
            )
            ->selectRaw(
                'SUM(CASE WHEN end_date IS NOT NULL AND end_date >= ? AND end_date <= ? THEN 1 ELSE 0 END) as expiring_soon_count',
                [$today, $within30],
            )
            ->selectRaw(
                'SUM(CASE WHEN end_date IS NULL OR end_date > ? THEN 1 ELSE 0 END) as active_count',
                [$within30],
            )
            ->first();

        $licenseStatusDistribution = [
            [
                'key' => 'active',
                'name_en' => 'Active',
                'name_ar' => 'نشط',
                'count' => (int) ($licenseStatusCounts?->active_count ?? 0),
            ],
            [
                'key' => 'expiring_soon',
                'name_en' => 'Expiring Soon',
                'name_ar' => 'ينتهي قريباً',
                'count' => (int) ($licenseStatusCounts?->expiring_soon_count ?? 0),
            ],
            [
                'key' => 'expired',
                'name_en' => 'Expired',
                'name_ar' => 'منتهي',
                'count' => (int) ($licenseStatusCounts?->expired_count ?? 0),
            ],
        ];

        $licensesByEnvironment = License::query()
            ->select('environment', DB::raw('COUNT(*) as count'))
            ->groupBy('environment')
            ->orderBy('environment')
            ->get()
            ->map(static function ($row): array {
                $environment = (string) $row->environment;

                return [
                    'key' => $environment,
                    'name_en' => $environment,
                    'name_ar' => $environment,
                    'count' => (int) $row->count,
                ];
            })
            ->values()
            ->all();

        $recentActivity = Activity::query()
            ->with(['causer', 'subject'])
            ->latest('created_at')
            ->limit(20)
            ->get()
            ->map(static function (Activity $activity): array {
                $causer = $activity->causer;
                $subject = $activity->subject;

                return [
                    'id' => $activity->id,
                    'description' => $activity->description,
                    'event' => $activity->event,
                    'log_name' => $activity->log_name,
                    'created_at' => $activity->created_at?->toIso8601String(),
                    'causer' => $causer !== null ? [
                        'id' => $causer->getKey(),
                        'type' => $causer->getMorphClass(),
                        'name' => method_exists($causer, 'getAttribute') && $causer->getAttribute('full_name')
                            ? (string) $causer->getAttribute('full_name')
                            : (method_exists($causer, 'getAttribute') ? (string) ($causer->getAttribute('email') ?? $causer->getKey()) : (string) $causer->getKey()),
                    ] : null,
                    'subject' => $subject !== null ? [
                        'id' => $subject->getKey(),
                        'type' => $subject->getMorphClass(),
                    ] : null,
                ];
            })
            ->all();

        return [
            'totals' => [
                'applications' => Application::query()->count(),
                'active_users' => User::query()->where('is_active', true)->count(),
                'vendors' => Vendor::query()->count(),
                'technologies' => Technology::query()->where('is_active', true)->count(),
                'licenses' => License::query()->count(),
                'assignments' => ApplicationAssignment::query()->count(),
                'open_assignments' => ApplicationAssignment::query()->open()->count(),
            ],
            'charts' => [
                'applications_by_status' => $applicationsByStatus,
                'assignments_by_app_role' => $assignmentsByRole,
                'technologies_usage' => $technologiesUsage,
                'employees_per_application' => $employeesPerApplication,
                'applications_by_department' => $applicationsByDepartment,
                'applications_by_ha_model' => $applicationsByHaModel,
                'license_usage' => $licenseUsage,
                'infra_license_usage' => $infraLicenseUsage,
                'service_desk_license_usage' => $serviceDeskLicenseUsage,
                'network_ops_license_usage' => $networkOpsLicenseUsage,
                'smart_facilities_license_usage' => $smartFacilitiesLicenseUsage,
                'license_status_distribution' => $licenseStatusDistribution,
                'licenses_by_environment' => $licensesByEnvironment,
            ],
            'recent_activity' => $recentActivity,
        ];
    }

    /**
     * Licensed / used / available totals for one of the independent license
     * catalogues (Apps, Infrastructure or Service Desk).
     *
     * @param  class-string<License|InfraLicense|ServiceDeskLicense|NetworkOpsLicense|SmartFacilitiesLicense>  $modelClass
     * @return list<array{key: string, name_en: string, name_ar: string, count: int}>
     */
    private function licenseUsageChart(string $modelClass): array
    {
        $totals = $modelClass::query()
            ->selectRaw('COALESCE(SUM(licensed), 0) as total_licensed')
            ->selectRaw('COALESCE(SUM(used), 0) as total_used')
            ->selectRaw('COALESCE(SUM(available), 0) as total_available')
            ->first();

        return [
            [
                'key' => 'licensed',
                'name_en' => 'Licensed',
                'name_ar' => 'مرخص',
                'count' => (int) ($totals?->total_licensed ?? 0),
            ],
            [
                'key' => 'used',
                'name_en' => 'Used',
                'name_ar' => 'مستخدم',
                'count' => (int) ($totals?->total_used ?? 0),
            ],
            [
                'key' => 'available',
                'name_en' => 'Available',
                'name_ar' => 'متاح',
                'count' => (int) ($totals?->total_available ?? 0),
            ],
        ];
    }
}
